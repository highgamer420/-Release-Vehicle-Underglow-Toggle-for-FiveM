fx_version 'cerulean'
game 'gta5'

-- Add this line to specify Lua 5.4
lua54 'yes'

author 'Crazy Eyes studio'
description 'toggle your vehicles underglow on and off'
version '1.0.0'

client_script 'config.lua'
client_script 'client.lua'
