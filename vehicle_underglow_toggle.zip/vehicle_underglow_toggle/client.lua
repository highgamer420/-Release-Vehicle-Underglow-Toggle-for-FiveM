-- Function to toggle the vehicle's underglow
local function toggleUnderglow()
    local playerPed = PlayerPedId()
    if IsPedInAnyVehicle(playerPed, false) then
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local hasUnderglow = false

        -- Check if any underglow is on
        for i = 0, 3 do
            if IsVehicleNeonLightEnabled(vehicle, i) then
                hasUnderglow = true
                break
            end
        end

        -- Toggle underglow
        for i = 0, 3 do
            SetVehicleNeonLightEnabled(vehicle, i, not hasUnderglow)
        end
    end
end

-- Register command to toggle underglow
RegisterCommand("glow", function()
    toggleUnderglow()
end, false)

